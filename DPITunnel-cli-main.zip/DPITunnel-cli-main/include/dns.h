#ifndef DNS_H
#define DNS_H

#include <string>

int resolve_host(const std::string &host, std::string &ip);

#endif //DNS_H
