/* SPDX-License-Identifier: LGPL-2.1-only */

#ifndef NETLINK_ROUTE_UTILS_PRIV_H_
#define NETLINK_ROUTE_UTILS_PRIV_H_

extern const uint8_t *const _nltst_map_stat_id_from_IPSTATS_MIB_v2;

#endif
